# CHANGELOG

\1- Añadido `/docs/01_STACK_Y_ARQUITECTURA.md` (stack, entornos v2/main, límites operativos y variables críticas a nivel conceptual).
- API: inventario de endpoints generado desde `src/app/api/**/route.ts` (v2) y documentado en `04_API_BACKEND.md`.
- Se formaliza el “Libro de la App” y se adopta `00_MANIFIESTO.md`.
- Se documenta modelo de dominio (Producto/Bulk/Oferta/Presentación).
- Se documentan jobs y playbooks de pricing-daily.
## 2026-02-16
- Añadido flujos End-to-End oficiales en `/docs/08_PLAYBOOKS_OPERATIVOS.md`.
