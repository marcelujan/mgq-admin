# 08_PLAYBOOKS_OPERATIVOS.md
## Flujos End-to-End Oficiales – mgq-admin

Este documento describe cómo funciona el sistema de forma secuencial,
conectando DB + API + UI + Jobs.

---

# 1. Crear Producto (Formulado)

### Paso 1 – Crear producto
- Se crea registro en `producto`.
- Automáticamente se crea `item_formulado` tipo `BULK` asociado.

Invariante:
Producto formulado → siempre tiene su representación técnica BULK.

---

# 2. Editar Fórmula

### Paso 1 – Crear header
- Registro en `producto_formula_v2`.

### Paso 2 – Agregar líneas
- Registros en `producto_formula_linea_v2`.
- Tipos posibles:
  - INSUMO
  - BULK_PRODUCTO
  - MANUAL

Resultado esperado:
- El producto puede calcular costo por kg.
- Puede actuar como bulk reutilizable.

---

# 3. Generación de Bulk

El BULK no es un objeto separado dinámico.

Es la representación técnica del producto:
- Se calcula vía endpoint `/api/productos/:id/costo-bulk`.
- No depende de presentación ni packaging.

---

# 4. Crear Oferta Comercial

### Paso 1 – Crear oferta
- Registro en `offers`.
- Se define:
  - item_id
  - presentacion
  - motor_id
  - url
  - estado

Regla crítica:
`presentacion` debe existir en el proveedor.

---

# 5. Pricing Diario

### Paso 1 – Crear/usar run
- Registro en `pricing_daily_runs`.

### Paso 2 – Insertar run_items
- Registros en `pricing_daily_run_items` (PENDING).

### Paso 3 – Scrape por grupos (motor_id + url)

### Paso 4 – Insert en `item_price_daily_pres`.

### Paso 5 – Actualizar estados
- OK
- FAIL
- PENDING

Estado final esperado:
- `pending_count = 0`.
- status = DONE.

---

# 6. Cálculo Costos Manuales

Se ejecuta después de pricing si no hay pendientes.

Actualiza snapshots relacionados a manuales.

---

# 7. Cálculo Costos Formulados

Calcula costos derivados de productos formulados.

Actualiza snapshots comerciales.

---

# 8. Uso de Bulk dentro de otra Fórmula

Un producto A puede incluir como línea:
- BULK_PRODUCTO → referencia a producto B.

Regla:
No se usa oferta, se usa costo técnico del bulk.

---

# 9. Fallos típicos documentados

- Presentación inexistente → FAIL en pricing.
- Cron no encadena → PARTIAL con pendientes.
- Densidad null → costo inválido.
- Offer sin motor/url → FAIL inmediato.

---

Fin de flujos oficiales v1.0
