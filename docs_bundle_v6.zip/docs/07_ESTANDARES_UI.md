# 07_ESTANDARES_UI.md
## Estándares de UI

## Estándar de Tablas v1.0 (modo compacto)

### Objetivo
Consistencia: mismas reglas de columnas, nombres, unidades y estados en toda la app.

### Reglas
1. La celda principal muestra **nombre** (no ID). El ID se muestra solo si es operativamente necesario.
2. Filas de **una sola línea**. Sin celdas multilinea, salvo excepción documentada.
3. Unidades obligatorias cuando aplique (%, g/ml, $/kg, L, kg).
4. Estados deben mostrarse como texto (badge opcional). Nunca solo color.
5. Dentro de una misma tabla: formato consistente (mismo set de columnas, mismas reglas).

### Excepciones permitidas
- Mostrar `last_error` puede ser multilinea o expandible.

