# 04_API_BACKEND.md
## API Backend – Inventario y contratos (v2)

Fuente: rutas Next.js App Router en `src/app/api/**/route.ts` (rama v2).

Notas:
- `Tablas (referencias)` se infiere por ocurrencias de `app.<tabla>` y `app_meta.<tabla>` dentro del archivo. Puede incluir falsos positivos/negativos si el SQL se arma dinámicamente.
- `Query params` se infiere por `searchParams.get(...)`.
- `Response keys` es una heurística basada en `NextResponse.json({ ... })` (solo claves top-level visibles en el literal).

---

## /api/componentes

### `/api/componentes`
- **Archivo:** `src/app/api/componentes/route.ts`
- **Métodos:** GET
- **Query params:** `search`
- **Tablas (referencias):** `insumo`, `producto`, `producto_oferta`
- **Response keys (heurístico):** `error`, `ok`

---

## /api/cost-options

### `/api/cost-options`
- **Archivo:** `src/app/api/cost-options/route.ts`
- **Métodos:** GET, POST
- **Query params:** `limit`, `search`, `solo_seleccionados`
- **Tablas (referencias):** `cost_option`, `cost_option_snapshot`, `item_price_daily_pres`, `item_seguimiento`, `proveedor`
- **Response keys (heurístico):** `cost_option_id`, `cost_options_extra`, `error`, `ok`

**Docstring / comentario:**

```
GET:
- ITEM_PRESENTACION: desde app.item_price_daily_pres (última fecha por item/presentación) + app.item_seguimiento + app.proveedor
- MANUAL/BULK: desde app.cost_option
```

### `/api/cost-options/[cost_option_id]`
- **Archivo:** `src/app/api/cost-options/[cost_option_id]/route.ts`
- **Métodos:** PATCH
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `cost_option`, `cost_option_snapshot`, `formula_linea_v2`
- **Response keys (heurístico):** `cost_option_id`, `error`, `ok`

---

## /api/cron

### `/api/cron/formulado-costs-daily`
- **Archivo:** `src/app/api/cron/formulado-costs-daily/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `item_formulado`, `item_formulado_snapshot`, `producto_costos_produccion`
- **Response keys (heurístico):** `error`, `ok`

### `/api/cron/manual-costs-daily`
- **Archivo:** `src/app/api/cron/manual-costs-daily/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `cost_option`, `cost_option_snapshot`
- **Response keys (heurístico):** `error`, `ok`

### `/api/cron/pricing-daily`
- **Archivo:** `src/app/api/cron/pricing-daily/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `item_price_daily_pres`, `offers`, `pricing_daily_run_items`, `pricing_daily_runs`
- **Response keys (heurístico):** `batch_size`, `chain_max`, `concurrency`, `date`, `error`, `fail`, `groups`, `handler_version`, `max_attempts`, `ok`, `pending_remaining`, `pg`, `run_id`, `scrape`, `time_budget_ms`, `time_margin_ms`

### `/api/cron/recalc-snapshots`
- **Archivo:** `src/app/api/cron/recalc-snapshots/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_formula_v2`
- **Response keys (heurístico):** `error`, `ok`, `processed_error`, `processed_ok`, `total`

---

## /api/db-health

### `/api/db-health`
- **Archivo:** `src/app/api/db-health/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** (ninguna detectada)
- **Response keys (heurístico):** `db`, `error`, `ok`

---

## /api/insumos

### `/api/insumos`
- **Archivo:** `src/app/api/insumos/route.ts`
- **Métodos:** GET, POST
- **Query params:** `activo`, `limit`, `offset`, `search`, `tipo_uom`
- **Tablas (referencias):** `insumo`
- **Response keys (heurístico):** `count`, `error`, `ok`

### `/api/insumos/[insumo_id]`
- **Archivo:** `src/app/api/insumos/[insumo_id]/route.ts`
- **Métodos:** GET, PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo`, `insumo_fuente`
- **Response keys (heurístico):** `error`, `ok`

### `/api/insumos/[insumo_id]/fuentes`
- **Archivo:** `src/app/api/insumos/[insumo_id]/fuentes/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo`, `insumo_fuente`, `producto_oferta`
- **Response keys (heurístico):** `error`, `ok`

### `/api/insumos/[insumo_id]/fuentes/[fuente_id]`
- **Archivo:** `src/app/api/insumos/[insumo_id]/fuentes/[fuente_id]/route.ts`
- **Métodos:** PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo_fuente`
- **Response keys (heurístico):** `error`, `ok`

---

## /api/items

### `/api/items`
- **Archivo:** `src/app/api/items/route.ts`
- **Métodos:** GET
- **Query params:** `estado`, `limit`, `offset`, `search`, `seleccionado`, `tipo`
- **Tablas (referencias):** `cost_option`, `cost_option_snapshot`, `item_formulado`, `item_formulado_snapshot`, `item_price_daily_pres`, `item_seguimiento`, `producto`, `producto_formula_linea_v2`, `producto_formula_v2`, `proveedor`
- **Response keys (heurístico):** `count`, `error`, `ok`

**Docstring / comentario:**

```
Unificación de Items:
- PROVEEDOR: app.item_seguimiento
- FORMULADO (virtual): producto con fórmula v2 (por header o por líneas)
- MANUAL (catálogo): app.cost_option tipo='MANUAL_PRESENTACION'
item_key:
- p:<item_id>
- fprod:<producto_id>
- mopt:<cost_option_id>
```

### `/api/items/[item_id]/price-history`
- **Archivo:** `src/app/api/items/[item_id]/price-history/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `cost_option_snapshot`, `item_formulado`, `item_formulado_snapshot`, `item_price_daily_pres`
- **Response keys (heurístico):** `error`, `id`, `item_key`, `kind`, `label`, `note`, `ok`, `raw`, `series`, `unit`

### `/api/items/bulk`
- **Archivo:** `src/app/api/items/bulk/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `item_seguimiento`, `offers`
- **Response keys (heurístico):** `error`, `ok`, `time_ms`

---

## /api/jobs

### `/api/jobs`
- **Archivo:** `src/app/api/jobs/route.ts`
- **Métodos:** GET, POST
- **Query params:** `estado`, `limit`
- **Tablas (referencias):** `item_seguimiento`, `job`, `job_estado`, `job_tipo`, `oferta_proveedor`
- **Response keys (heurístico):** `error`, `job_ids`, `jobs`, `ok`

**Docstring / comentario:**

```
Normaliza el resultado del cliente SQL (Neon/pg)
a un array de filas (objetos).
```

### `/api/jobs/[job_id]`
- **Archivo:** `src/app/api/jobs/[job_id]/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `item_seguimiento`, `job`, `job_result`
- **Response keys (heurístico):** `corrida_id`, `error`, `item_id`, `job`, `job_id`, `motor_id`, `ok`, `proveedor_id`

### `/api/jobs/[job_id]/approve`
- **Archivo:** `src/app/api/jobs/[job_id]/approve/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `item_estado`, `item_seguimiento`, `job`, `job_estado`, `job_result`, `oferta_proveedor`, `uom`
- **Response keys (heurístico):** `actual`, `already_succeeded`, `aprobar`, `error`, `errors`, `inserted_count`, `oferta_id`, `oferta_ids`, `ok`, `skipped_existing`

### `/api/jobs/run-next`
- **Archivo:** `src/app/api/jobs/run-next/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `fx`, `item_seguimiento`, `job`, `job_estado`, `job_result`, `job_result_status`
- **Response keys (heurístico):** `claimed`, `error`, `item_id`, `job`, `job_id`, `motor_id`, `ok`, `tipo`

**Docstring / comentario:**

```
Opción B (configurable por proveedor) sin tocar DB:
configuración por hostname de la URL.
```

---

## /api/jobs-diario

### `/api/jobs-diario`
- **Archivo:** `src/app/api/jobs-diario/route.ts`
- **Métodos:** GET
- **Query params:** `run_id`
- **Tablas (referencias):** `item_seguimiento`, `offer_prices_daily`, `offers`, `pricing_daily_run_items`, `pricing_daily_runs`, `proveedor`
- **Response keys (heurístico):** `error`, `ok`, `rows`, `run`

---

## /api/ofertas

### `/api/ofertas`
- **Archivo:** `src/app/api/ofertas/route.ts`
- **Métodos:** GET, POST
- **Query params:** `item_id`
- **Tablas (referencias):** `motor_proveedor`, `offers`, `proveedor`
- **Response keys (heurístico):** `count`, `error`, `inserted_created`, `inserted_updated`, `lido`, `motor_id`, `offers`, `ok`, `prices_len`, `proveedor_codigo`, `proveedor_id`, `url_canonica`

### `/api/ofertas/bulk`
- **Archivo:** `src/app/api/ofertas/bulk/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `item_seguimiento`, `offers`, `proveedor`
- **Response keys (heurístico):** `code`, `debug`, `detail`, `error`, `hint`, `inactivo`, `inexistente`, `ok`, `pg`, `proveedor_nombre`, `where`

**Docstring / comentario:**

```
Crea:
 - 1 fila en app.item_seguimiento por URL (si no existe)
 - N filas en app.offers (una por presentación encontrada por el motor)
```

### `/api/ofertas/bulk/preview`
- **Archivo:** `src/app/api/ofertas/bulk/preview/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `proveedor`
- **Response keys (heurístico):** `error`, `motor_id`, `ok`

---

## /api/packaging-items

### `/api/packaging-items`
- **Archivo:** `src/app/api/packaging-items/route.ts`
- **Métodos:** GET, POST
- **Query params:** `include_inactivos`
- **Tablas (referencias):** `packaging_item`
- **Response keys (heurístico):** `error`, `items`, `ok`

### `/api/packaging-items/[packaging_item_id]`
- **Archivo:** `src/app/api/packaging-items/[packaging_item_id]/route.ts`
- **Métodos:** PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `packaging_item`
- **Response keys (heurístico):** `borrar`, `error`, `ok`

---

## /api/ping

### `/api/ping`
- **Archivo:** `src/app/api/ping/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** (ninguna detectada)
- **Response keys (heurístico):** `has_neon`

---

## /api/productos

### `/api/productos`
- **Archivo:** `src/app/api/productos/route.ts`
- **Métodos:** GET, POST
- **Query params:** `activo`, `limit`, `offset`, `search`
- **Tablas (referencias):** `producto`, `producto_base`, `producto_formula`
- **Response keys (heurístico):** `count`, `error`, `ok`

### `/api/productos/[producto_id]`
- **Archivo:** `src/app/api/productos/[producto_id]/route.ts`
- **Métodos:** GET, PATCH
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto`, `producto_base`, `producto_formula`, `producto_formula_linea`
- **Response keys (heurístico):** `base`, `error`, `formula`, `lineas`, `ok`, `producto`

**Docstring / comentario:**

```
PATCH /api/productos/:producto_id
Body permitido (por ahora):
- densidad_producto_g_ml: number | null
```

### `/api/productos/[producto_id]/base`
- **Archivo:** `src/app/api/productos/[producto_id]/base/route.ts`
- **Métodos:** GET, PUT, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_base`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/[producto_id]/costo-bulk`
- **Archivo:** `src/app/api/productos/[producto_id]/costo-bulk/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `cost_option`, `item_price_daily_pres`, `producto_costos_produccion`, `producto_formula_linea_v2`, `producto_formula_v2`
- **Response keys (heurístico):** `ars_por_g`, `ars_por_kg`, `error`, `lote_ref_g`, `material_ars_por_kg`, `ok`, `prod_ars_por_kg`

### `/api/productos/[producto_id]/formula`
- **Archivo:** `src/app/api/productos/[producto_id]/formula/route.ts`
- **Métodos:** GET, PUT, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_formula`, `producto_formula_linea`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/[producto_id]/formula-v2`
- **Archivo:** `src/app/api/productos/[producto_id]/formula-v2/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_costos_produccion`, `producto_formula_v2`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/[producto_id]/formula-v2/lineas`
- **Archivo:** `src/app/api/productos/[producto_id]/formula-v2/lineas/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `cost_option`, `item_price_daily_pres`, `producto_formula_linea_v2`
- **Response keys (heurístico):** `error`, `lineas`, `ok`

### `/api/productos/[producto_id]/formula-v2/lineas/[linea_id]`
- **Archivo:** `src/app/api/productos/[producto_id]/formula-v2/lineas/[linea_id]/route.ts`
- **Métodos:** PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_formula_linea_v2`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/[producto_id]/formula/lineas`
- **Archivo:** `src/app/api/productos/[producto_id]/formula/lineas/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo`, `producto_formula_linea`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/[producto_id]/formula/lineas/[linea_id]`
- **Archivo:** `src/app/api/productos/[producto_id]/formula/lineas/[linea_id]/route.ts`
- **Métodos:** PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo`, `producto_formula_linea`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/[producto_id]/ofertas`
- **Archivo:** `src/app/api/productos/[producto_id]/ofertas/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/bulks`
- **Archivo:** `src/app/api/productos/bulks/route.ts`
- **Métodos:** GET
- **Query params:** `search`
- **Tablas (referencias):** `item_formulado`, `producto`
- **Response keys (heurístico):** `error`, `ok`

**Docstring / comentario:**

```
GET /api/productos/bulks?search=&limit=&offset=&exclude_producto_id=
"Bulk disponible" = item_formulado tipo BULK activo.
Devuelve productos + densidad + ars_por_kg.
```

### `/api/productos/ofertas/[oferta_id]`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/route.ts`
- **Métodos:** GET, PATCH
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta`
- **Response keys (heurístico):** `error`, `ok`, `skipped`

### `/api/productos/ofertas/[oferta_id]/costeo`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/costeo/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo`, `insumo_fuente`, `item_price_daily_pres`, `producto`, `producto_base`, `producto_formula`, `producto_formula_linea`, `producto_oferta`, `producto_oferta_extra`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/ofertas/[oferta_id]/costo-snapshots`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/costo-snapshots/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta_costo_snapshot`, `producto_oferta_costo_snapshot_packaging`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/ofertas/[oferta_id]/costo-snapshots/[snapshot_id]`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/costo-snapshots/[snapshot_id]/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta_costo_snapshot`, `producto_oferta_costo_snapshot_packaging`
- **Response keys (heurístico):** `error`, `ok`, `packaging`, `snapshot`

### `/api/productos/ofertas/[oferta_id]/duplicate`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/duplicate/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta`, `producto_oferta_extra`
- **Response keys (heurístico):** `error`, `oferta_id`, `ok`

### `/api/productos/ofertas/[oferta_id]/extras`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/extras/route.ts`
- **Métodos:** POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `insumo`, `producto_oferta_extra`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/ofertas/[oferta_id]/extras/[extra_id]`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/extras/[extra_id]/route.ts`
- **Métodos:** PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta_extra`
- **Response keys (heurístico):** `error`, `ok`

### `/api/productos/ofertas/[oferta_id]/packaging`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/packaging/route.ts`
- **Métodos:** GET, POST
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `oferta_packaging`, `packaging_item`
- **Response keys (heurístico):** `error`, `ok`, `rows`

### `/api/productos/ofertas/[oferta_id]/packaging/[oferta_packaging_id]`
- **Archivo:** `src/app/api/productos/ofertas/[oferta_id]/packaging/[oferta_packaging_id]/route.ts`
- **Métodos:** PATCH, DELETE
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `producto_oferta_packaging`
- **Response keys (heurístico):** `error`, `ok`

---

## /api/proveedores

### `/api/proveedores`
- **Archivo:** `src/app/api/proveedores/route.ts`
- **Métodos:** GET
- **Query params:** (ninguno detectado)
- **Tablas (referencias):** `motor_proveedor`, `oferta_proveedor`, `proveedor`
- **Response keys (heurístico):** `motor_id`, `null`, `ok`, `proveedor_id`, `proveedor_nombre`, `proveedores`

---
