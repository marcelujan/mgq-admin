# 02_MODELO_DE_DOMINIO.md
## Modelo de Dominio – mgq-admin

## 1. Producto

### Definición formal

Un **Producto** es un contenedor de fórmula que genera automáticamente un “bulk” y puede convertirse en entidad comercial vendible cuando se le asigna presentación/packaging y se crea una oferta con su item formulado.

Roles simultáneos:

1. **Técnico**: contenedor de fórmula.
2. **Comercial**: vendible cuando se materializa como oferta.

## 2. Item formulado

Entidad que representa una formulación reutilizable.

### 2.1 Bulk

**Bulk** = representación formulada reutilizable (técnica) de un producto.

Identificación:

- `item_formulado.tipo = 'BULK'`
- `item_formulado.activo = true`

## 3. Oferta

Una **Oferta** materializa un ítem comercial en una **presentación** (tamaño). Campos semánticos clave:

- `item_id`
- `presentacion`
- `motor_id`
- `url_canonica`
- `estado`

### 3.1 Presentación

Regla crítica:

- `offers.presentacion` debe existir en las presentaciones detectadas por el motor para la URL.
- No se aproxima automáticamente (p. ej. 50→100).

## 4. Pricing diario

Proceso automático que:

1. Scrapea precios por presentación.
2. Actualiza precios diarios.
3. Marca cada oferta como OK/FAIL.

## 5. Invariantes globales

1. Producto cumple doble rol (técnico y comercial).
2. Bulk es la representación técnica reutilizable.
3. Oferta es la entidad comercial concreta.
4. Presentación debe existir en scraping.
5. Pricing es idempotente por fecha.

