# 06_JOBS_Y_AUTOMATIZACIONES.md
## Jobs y automatizaciones (Vercel cron)

Fuente de cron schedule: `vercel.json`.

## 1. Cron: /api/cron/pricing-daily (03:10)

### Propósito
Scrapear precios desde proveedores (por oferta) y persistir el precio diario por presentación.

### Entradas
- `app.offers` filtrando `estado='OK'`.
- `offers.presentacion` (presentación objetivo).
- `offers.motor_id` y `offers.url_*`.

### Salidas (DB)
- `app.pricing_daily_runs` (por `as_of_date`).
- `app.pricing_daily_run_items` (1 por offer, estado PENDING/OK/FAIL, attempts, last_error).
- `app.item_price_daily_pres` (upsert por `(item_id, as_of_date, presentacion)`).

### Estados
- `pricing_daily_run_items.status`: PENDING | OK | FAIL
- `pricing_daily_runs.status`: RUNNING | DONE | PARTIAL

### Errores relevantes
- `missing_motor_or_url(...)` → oferta incompleta.
- `offer_presentacion_missing(...)` → oferta sin presentación.
- `no_or_invalid_price_for_presentacion:<pres>` → el motor no devolvió precio para la presentación guardada.

### Encadenamiento
El job puede auto-invocarse para continuar mientras haya pendientes (hasta `PRICING_CHAIN_MAX`).

### Verificación rápida
- `select status, count(*) from app.pricing_daily_run_items where run_id=<id> group by status;`
- `select status, pending_count, fail_count from app.pricing_daily_runs where id=<id>;`

## 2. Cron: /api/cron/manual-costs-daily (03:15)

### Propósito
Snapshot diario de costos manuales (cost options manuales por presentación).

### Fuente
- `app.cost_option` (`activo=true` y `tipo='MANUAL_PRESENTACION'`).

### Destino
- `app.cost_option_snapshot` upsert por `(cost_option_id, as_of_date)` con `fuente='CRON'`.

### Verificación rápida
- `select count(*) from app.cost_option_snapshot where as_of_date=current_date;`

## 3. Cron: /api/cron/formulado-costs-daily (03:20)

### Propósito
Snapshot diario del costo unitario de los formulados BULK.

### Fuente
- `app.item_formulado` (`tipo='BULK' and activo=true`).
- `app.producto_costos_produccion` (para sumar variable + fijo/lote si corresponde).

### Destino
- `app.item_formulado_snapshot` upsert por `(item_formulado_id, as_of_date)`.

### Verificación rápida
- `select count(*) from app.item_formulado_snapshot where as_of_date=current_date;`

## 4. Endpoint: /api/cron/recalc-snapshots (no programado)

### Propósito
Recalcular snapshots por producto con fórmula v2 (recorre `app.producto_formula_v2`).

### Observación
Este endpoint permite “rebuild” cuando hay cambios en costos o reglas.

