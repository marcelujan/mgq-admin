# 05_FRONTEND.md

(pendiente)
