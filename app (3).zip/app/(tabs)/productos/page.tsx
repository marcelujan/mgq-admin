export default function ProductosPage() { return <div className="text-sm">Productos — placeholder.</div>; }
