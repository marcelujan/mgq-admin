export default function ComprasPage() { return <div className="text-sm">Compras — placeholder.</div>; }
