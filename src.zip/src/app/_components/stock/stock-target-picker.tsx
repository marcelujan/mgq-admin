"use client";

import { useEffect, useState } from "react";

export type StockTargetTipo = "PROVEEDOR" | "MANUAL" | "FORMULADO" | "ENVASE" | "ETIQUETA" | "PAQUETERIA";

export type StockTargetItem = {
  item_tipo: StockTargetTipo;
  item_ref_id: number;
  label?: string;
  nombre: string;
  uom: string | null;
  saldo?: number | null;
  costo_ref_ars?: number | null;
  densidad_g_ml?: number | null;
};

const tableCell = { padding: "5px 8px", whiteSpace: "nowrap" as const, overflow: "hidden" as const, textOverflow: "ellipsis" as const };

export default function StockTargetPicker({
  allowedTypes,
  value,
  onChange,
  label,
  placeholder = "Buscar...",
  maxVisibleRows = 6,
}: {
  allowedTypes: StockTargetTipo[];
  value: StockTargetItem | null;
  onChange: (item: StockTargetItem | null) => void;
  label?: string;
  placeholder?: string;
  maxVisibleRows?: number;
}) {
  const [tipo, setTipo] = useState<StockTargetTipo>(allowedTypes[0]);
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<StockTargetItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (!allowedTypes.includes(tipo)) setTipo(allowedTypes[0]);
  }, [allowedTypes, tipo]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setErr(null);
      try {
        const qp = new URLSearchParams({ tipo, search, limit: "1000" });
        const r = await fetch(`/api/stock-objetivos?${qp.toString()}`, { cache: "no-store" });
        const j = await r.json().catch(() => null);
        if (!r.ok || !j?.ok) throw new Error(j?.error || `HTTP ${r.status}`);
        if (!cancelled) setItems((j.items ?? []) as StockTargetItem[]);
      } catch (e: any) {
        if (!cancelled) {
          setItems([]);
          setErr(String(e?.message || e));
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [tipo, search]);

  const maxHeight = 34 + maxVisibleRows * 29;

  return (
    <div style={{ display: "grid", gap: 8, minWidth: 0 }}>
      {label ? <div style={{ fontSize: 12, opacity: 0.8 }}>{label}</div> : null}
      <div style={{ display: "grid", gridTemplateColumns: "160px minmax(0,1fr)", gap: 8 }}>
        <select
          value={tipo}
          onChange={(e) => {
            setTipo(e.target.value as StockTargetTipo);
            onChange(null);
          }}
          style={{ width: "100%", minWidth: 0, boxSizing: "border-box", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 10, padding: "8px 10px", background: "rgba(255,255,255,0.03)", color: "inherit" }}
        >
          {allowedTypes.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={placeholder}
          style={{ width: "100%", minWidth: 0, boxSizing: "border-box", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 10, padding: "8px 10px", background: "rgba(255,255,255,0.03)", color: "inherit" }}
        />
      </div>
      <div style={{ border: "1px solid rgba(255,255,255,0.10)", borderRadius: 12, overflow: "hidden" }}>
        <div style={{ maxHeight, overflowY: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, tableLayout: "fixed" }}>
            <thead>
              <tr style={{ background: "rgba(255,255,255,0.03)" }}>
                <th style={{ textAlign: "left", padding: "5px 8px", width: 80, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>Item #</th>
                <th style={{ textAlign: "left", padding: "5px 8px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>Nombre</th>
                <th style={{ textAlign: "right", padding: "5px 8px", width: 90, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>Saldo</th>
                <th style={{ textAlign: "left", padding: "5px 8px", width: 52, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>UOM</th>
                <th style={{ textAlign: "right", padding: "5px 8px", width: 64, borderBottom: "1px solid rgba(255,255,255,0.08)" }}>Dens.</th>
                <th style={{ textAlign: "left", padding: "5px 8px", width: 42, borderBottom: "1px solid rgba(255,255,255,0.08)" }}></th>
              </tr>
            </thead>
            <tbody>
              {items.map((it) => (
                <tr key={`${it.item_tipo}:${it.item_ref_id}`} style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                  <td style={{ ...tableCell, width: 80 }}>{it.item_ref_id}</td>
                  <td style={tableCell} title={it.label}>{it.label}</td>
                  <td style={{ ...tableCell, textAlign: "right", width: 90 }}>{new Intl.NumberFormat("es-AR", { maximumFractionDigits: 3 }).format(Number(it.saldo ?? 0))}</td>
                  <td style={{ ...tableCell, width: 52 }}>{it.uom ?? ""}</td>
                  <td style={{ ...tableCell, textAlign: "right", width: 64 }}>{it.densidad_g_ml != null ? new Intl.NumberFormat("es-AR", { maximumFractionDigits: 4 }).format(Number(it.densidad_g_ml)) : ""}</td>
                  <td style={{ ...tableCell, width: 42 }}><button type="button" onClick={() => onChange(it)} style={{ background: "transparent", border: "none", padding: 0, color: "inherit", cursor: "pointer", opacity: 0.9, fontSize: 13 }}>+</button></td>
                </tr>
              ))}
              {!loading && items.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ padding: "8px", opacity: 0.7 }}>{err ? err : "Sin resultados."}</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
      {value ? (
        <div style={{ border: "1px solid rgba(255,255,255,0.10)", borderRadius: 12, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, tableLayout: "fixed" }}>
            <thead>
              <tr style={{ background: "rgba(255,255,255,0.03)" }}>
                <th style={{ textAlign: "left", padding: "5px 8px", width: 80 }}>Item #</th>
                <th style={{ textAlign: "left", padding: "5px 8px" }}>Seleccionado</th>
                <th style={{ textAlign: "right", padding: "5px 8px", width: 90 }}>Saldo</th>
                <th style={{ textAlign: "left", padding: "5px 8px", width: 52 }}>UOM</th>
                <th style={{ textAlign: "right", padding: "5px 8px", width: 64 }}>Dens.</th>
                <th style={{ textAlign: "left", padding: "5px 8px", width: 42 }}></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ ...tableCell, width: 80 }}>{value.item_ref_id}</td>
                <td style={tableCell} title={value.label}>{value.label}</td>
                <td style={{ ...tableCell, textAlign: "right", width: 90 }}>{new Intl.NumberFormat("es-AR", { maximumFractionDigits: 3 }).format(Number(value.saldo ?? 0))}</td>
                <td style={{ ...tableCell, width: 52 }}>{value.uom ?? ""}</td>
                <td style={{ ...tableCell, textAlign: "right", width: 64 }}>{value.densidad_g_ml != null ? new Intl.NumberFormat("es-AR", { maximumFractionDigits: 4 }).format(Number(value.densidad_g_ml)) : ""}</td>
                <td style={{ ...tableCell, width: 42 }}><button type="button" onClick={() => onChange(null)} style={{ background: "transparent", border: "none", padding: 0, color: "inherit", cursor: "pointer", opacity: 0.9 }}>✕</button></td>
              </tr>
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
}
