export default function VentasPage() { return <div className="text-sm">Ventas — placeholder.</div>; }
