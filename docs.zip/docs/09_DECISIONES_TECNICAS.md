# 09_DECISIONES_TECNICAS.md
## Decisiones técnicas

(Registrar aquí decisiones que cambian reglas, dominios, endpoints o esquemas.)


## 2026-04-09 — Estándar de fechas operacionales

Se adopta la siguiente convención:

- `created_at` / `updated_at`: timestamps absolutos del sistema (Postgres / UTC).
- `as_of_date` / `fecha` de snapshots diarios: fecha operacional local de la app en `America/Argentina/Cordoba`.

Alcance del cambio implementado en esta iteración:
- alta por URL (`/api/ofertas`, `/api/ofertas/bulk`) deja de sembrar `item_price_daily_pres` con `current_date` implícito y usa una fecha calculada explícitamente en zona local de la app;
- la UI recibe `as_of_date` para reflejar la misma fecha usada por backend.

Fuera de alcance por ahora:
- migrar en una sola iteración todos los cron y snapshots existentes que hoy dependen de `current_date`.

## 2026-04-09 — SKU opcional en PuraQuimica

- `articulo_prov` sigue existiendo como campo opcional en `item_seguimiento`.
- En PuraQuimica la ausencia de SKU no bloquea ni degrada el preview/create.
- La identidad mínima aceptada del item proveedor PuraQuimica es `url_canonica` + `descripcion_fuente` cuando existe.

## 2026-04-14 — Dirección aceptada para capa comercial y packaging (no implementada)

Se acepta la siguiente organización objetivo, sin introducir todavía cambios de esquema ni de endpoints:

### Capas objetivo

1. **Capa técnica de origen**
   - `Items Proveedores`
   - `Items Manuales`
   - `Items Formulados`

2. **Capa de packaging operativo**
   - `Items Envases`
   - `Items Paquetería`

3. **Capa comercial**
   - `Items Comerciales`

### Definiciones aceptadas

- **Item Formulado**: debe tender a representar un **bulk técnico** reutilizable, no la unidad comercial final.
- **Item Comercial**: unidad comercializable creada manualmente solo para los casos de interés, derivada de un origen técnico (`PROVEEDOR`, `MANUAL` o `FORMULADO`) y con una presentación asociada.
- **Items Envases** e **Items Paquetería**: se manejarán como catálogos separados del resto de ítems y podrán tener origen `MANUAL` o `PROVEEDOR`.

### Reglas de trabajo aceptadas

- No habrá migración masiva de ítems existentes.
- Solo se crearán `Items Comerciales` para los casos que efectivamente se quieran comercializar.
- El pasaje desde el origen técnico al `Item Comercial` será explícito y manual.
- Las futuras hojas `Items Comerciales`, `Items Envases` e `Items Paquetería` deberán incorporarse luego a la hoja general `Items`.
- Antes de modificar `/api/items`, deberá definirse para cada nueva categoría la política operacional de `OK | FAIL | PEND` sin mezclarla con la completitud comercial.

### Impacto aceptado

- **Dominio actual**: sin cambios implementados en esta etapa.
- **Cron y snapshots**: sin cambios implementados en esta etapa; los snapshots vigentes continúan separados por dominio técnico (`pricing_daily_run_items`, `item_formulado_snapshot`, `cost_option_snapshot`).
- **Idempotencia**: sin impacto mientras la capa comercial no modifique los motores actuales de snapshot.

### Etiquetado y BarTender (línea futura)

Se deja asentado como criterio de diseño futuro:

- `mgq-admin` seguirá siendo la **fuente de verdad** de datos.
- El etiquetado deberá resolverse mediante una capa estandarizada consumible por **BarTender Designer 2022 R8** y por las impresoras operativas actuales.
- La integración con impresión deberá tratar a BarTender como consumidor de lectura para impresión estandarizada, no como origen de estados de negocio.

Esta decisión documenta una dirección aprobada de trabajo. No implica que la integración ni las nuevas hojas existan hoy en código.

